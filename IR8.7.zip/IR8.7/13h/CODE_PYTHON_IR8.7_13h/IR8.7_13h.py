import xml.etree.ElementTree as ET #pour lire les fichiers .XML
import xarray as xr #pour lire les fichiers .NC
import os
import numpy as np
import matplotlib.pyplot as plt
from pyproj import Proj, transform
#%% #récupèrer les fichiers

#où se trouvent tous les fichiers sur mon pc (13h09)
dossier = r"C:\Users\Louis\OneDrive\Documents\IPSA\PMI_13h\IR12.3_IR8.7_13h"

#analyse du fichier Manifest.xml
tree = ET.parse(os.path.join(dossier, "manifest.xml"))
root = tree.getroot()
ns = {'eum': 'http://www.eumetsat.int/sip'}

#on récupère tous les fichiers .nc
paths = [elem.text for elem in root.findall('.//eum:path', ns) if elem.text.endswith('.nc')]
#vérification du nombre de fichiers .nc récupérés
print("Nombre de fichiers trouvés :", len(paths))


#%% #pour tous les fichiers .nc

bt_87_list = []
for p in paths:
    fichier = os.path.join(dossier, p)
    #on ouvre le groupe IR8.7 mesuré
    ds_ir87_all = xr.open_dataset(fichier, group="data/ir_87/measured")
    #si pas de radiance mesurée, on skip
    if "effective_radiance" not in ds_ir87_all:
        ds_ir87_all.close()
        continue

    #récup des variables utiles
    eff_all = ds_ir87_all["effective_radiance"]
    k_rad_all = ds_ir87_all["radiance_unit_conversion_coefficient"]
    wn_all  = ds_ir87_all["radiance_to_bt_conversion_coefficient_wavenumber"]
    c1_all  = ds_ir87_all["radiance_to_bt_conversion_constant_c1"]
    c2_all  = ds_ir87_all["radiance_to_bt_conversion_constant_c2"]
    a_all   = ds_ir87_all["radiance_to_bt_conversion_coefficient_a"]
    b_all   = ds_ir87_all["radiance_to_bt_conversion_coefficient_b"]

    #passage radiance effective vers radiance "physique"
    L_all = eff_all * k_rad_all
    
    #BT planck + correction linéaire
    BT_planck_all = c2_all * wn_all / np.log(1 + (c1_all * wn_all**3) / L_all)
    BT_87_all = a_all * BT_planck_all + b_all
    BT_87_all.name = "BT_87"
    bt_87_list.append(BT_87_all)
    ds_ir87_all.close()

print("Nombre total de fichiers .nc traités pour IR8.7 :", len(bt_87_list))


#%% #combiner tous les fichiers .nc

#on convertit chaque DataArray en Dataset pour que combine_by_coords marche
bt_87_ds_list = [da.to_dataset() for da in bt_87_list]

#on combine par coordonnées (x, y)
bt_87_full_ds = xr.combine_by_coords(bt_87_ds_list)


#on récupère la DataArray
bt_87_full = bt_87_full_ds["BT_87"]


bt_87_full = bt_87_full.sortby('x', ascending=False)

#%% Interpolation

print(f"Dimensions image IR8.7 AVANT interpolation : {bt_87_full.shape}")

# Interpolation bilinéaire vers 11136x11136
bt_87_full = bt_87_full.interp(
    x=np.linspace(bt_87_full.x.min(), bt_87_full.x.max(), 11136),
    y=np.linspace(bt_87_full.y.min(), bt_87_full.y.max(), 11136),
    method='linear'
)

print(f"Dimensions image IR8.7 APRÈS interpolation : {bt_87_full.shape}")



#%% #affichage du monde entier

# plt.figure(figsize=(10,8))
# bt_87_full.plot.imshow()
# plt.gca().invert_xaxis() 
# plt.xlabel("")  
# plt.ylabel("")
# plt.title("BT 8.7 µm (K)")
# plt.show()


#%% #sauvegarde données du monde entier

# bt_87_full.to_netcdf("bt_87_13h.nc")


#%% CALCUL DES COORDONNÉES GÉOGRAPHIQUES
# Les coordonnées x,y sont en radians dans la projection géostationnaire
# Il faut les convertir en latitude/longitude

# Récupérer les coordonnées x et y (en radians)
x_coords = bt_87_full.x.values  # Array 1D des coordonnées x
y_coords = bt_87_full.y.values  # Array 1D des coordonnées y

# Créer une grille 2D à partir des coordonnées 1D
Y, X = np.meshgrid(y_coords, x_coords, indexing='ij')

# PARAMÈTRES DU SATELLITE MTG
satellite_height = 35786023.0  # Altitude du satellite en mètres (35786 km)
satellite_longitude = 0.0  # Le satellite MTG-I1 est positionné à 0°E

# CONVERSION : Radians vers Mètres
X_m = X * satellite_height
Y_m = Y * satellite_height

# DÉFINIR LES PROJECTIONS
proj_geos = Proj(f'+proj=geos +lon_0={satellite_longitude} +h={satellite_height} +x_0=0 +y_0=0 +ellps=WGS84 +units=m +no_defs +sweep=y')
proj_latlon = Proj('+proj=latlong +ellps=WGS84')

# CONVERSION : Projection géostationnaire Lat/Lon
lon, lat = transform(proj_geos, proj_latlon, X_m.flatten(), Y_m.flatten())

# RESHAPE : Revenir à une grille 2D
lon = lon.reshape(X.shape)
lat = lat.reshape(X.shape)


#%% ZOOM SUR TOULOUSE
# Maintenant qu'on a les coordonnées géographiques, on peut localiser Toulouse

lat_tlse = 43.6045  # Latitude de Toulouse
lon_tlse = -1.4440  # Longitude de Toulouse

# TROUVER LE PIXEL LE PLUS PROCHE DE TOULOUSE
dist = np.sqrt((lat - lat_tlse)**2 + (lon - lon_tlse)**2)

# Trouver l'indice du pixel avec la distance minimale
iy, ix = np.unravel_index(np.argmin(dist), dist.shape)

# DÉFINIR UNE FENÊTRE AUTOUR DE TOULOUSE
radius = 500 # Nombre de pixels de part et d'autre de Toulouse

# Calculer les limites du zoom en s'assurant de rester dans l'image
x_min = max(ix - radius, 0)
x_max = min(ix + radius, bt_87_full.sizes["x"])
y_min = max(iy - radius, 0)
y_max = min(iy + radius, bt_87_full.sizes["y"])

# EXTRAIRE LES DONNÉES DU ZOOM
# Pour les données xarray, on garde l'ordre original
bt_zoom = bt_87_full.isel(x=slice(x_min, x_max), y=slice(y_min, y_max))

# Sauvegarder les données sur le zoom
bt_zoom.to_netcdf("bt_87_zoom_toulouse_13h.nc")
# Pour les coordonnées, on extrait les mêmes indices
# IMPORTANT: Ces indices correspondent aux tableaux lat/lon qui ont la même forme
lat_zoom = lat[y_min:y_max, x_min:x_max]
lon_zoom = lon[y_min:y_max, x_min:x_max]

#%% AFFICHAGE DU ZOOM 

plt.figure(figsize=(10, 10))

# On utilise pcolormesh avec les coordonnées et données dans le même ordre
# On n'applique pas de sortby pour éviter les incohérences
plt.pcolormesh(lon_zoom, lat_zoom, bt_zoom.values, shading='auto', cmap='RdYlBu_r')

# Ajouter un point rouge pour Toulouse
plt.scatter(lon_tlse, lat_tlse, color="red", s=100, marker='.', 
            edgecolors='white', linewidths=2, label="Toulouse", zorder=10)

# CORRECTION: Pour corriger l'effet miroir, on inverse l'axe x
plt.gca().invert_xaxis()



plt.xlabel("Longitude (°)")
plt.ylabel("Latitude (°)")
plt.title("IR8.7 – Toulouse - 13h")
plt.grid(True, alpha=0.3, linestyle='--')
plt.tight_layout()
plt.savefig('IR8.7_13h.png') 
plt.show()